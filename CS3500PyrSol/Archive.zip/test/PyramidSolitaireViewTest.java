import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw04.MultiPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.view.PyramidSolitaireTextualView;
import cs3500.pyramidsolitaire.view.PyramidSolitaireView;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * View test for the Pyramid solitaire.
 */
public class PyramidSolitaireViewTest {

  @Test
  public void viewBasicTest1() {
    // initializes BasicPyramidSolitaire model
    PyramidSolitaireModel<Card> model = new BasicPyramidSolitaire();
    // initializes view to be given model
    PyramidSolitaireView view = new PyramidSolitaireTextualView(model);
    // calls startGame
    model.startGame(model.getDeck(), false, 7, 3);
    assertEquals("            A♣\n"
            + "          A♦  A♥\n"
            + "        A♠  2♣  2♦\n"
            + "      2♥  2♠  3♣  3♦\n"
            + "    3♥  3♠  4♣  4♦  4♥\n"
            + "  4♠  5♣  5♦  5♥  5♠  6♣\n"
            + "6♦  6♥  6♠  7♣  7♦  7♥  7♠\n"
            + "Draw: 8♣, 8♦, 8♥\n", view.toString());
  }

  @Test
  public void viewBasicTest2() {
    // initializes BasicPyramidSolitaire model
    PyramidSolitaireModel<Card> model = new BasicPyramidSolitaire();
    // initializes view to be given model
    PyramidSolitaireView view = new PyramidSolitaireTextualView(model);
    // calls startGame
    model.startGame(model.getDeck(), false, 7, 3);
    assertEquals("            A♣\n"
            + "          A♦  A♥\n"
            + "        A♠  2♣  2♦\n"
            + "      2♥  2♠  3♣  3♦\n"
            + "    3♥  3♠  4♣  4♦  4♥\n"
            + "  4♠  5♣  5♦  5♥  5♠  6♣\n"
            + "6♦  6♥  6♠  7♣  7♦  7♥  7♠\n"
            + "Draw: 8♣, 8♦, 8♥\n", view.toString());
  }

  @Test
  public void viewMultiTest1() {
    // initializes MultiPyramidSolitaire model
    PyramidSolitaireModel<Card> multiModel = new MultiPyramidSolitaire();
    // initializes view to be given model
    PyramidSolitaireView view = new PyramidSolitaireTextualView(multiModel);

    // calls startGame
    multiModel.startGame(multiModel.getDeck(), true, 7, 3);
    assertEquals("            8♣  .  .  2♠  .  .  J♠\n"
            + "          6♦  9♦  .  J♥  8♥  .  7♣  6♣\n"
            + "        3♣  10♠ 9♠  3♥  4♥  4♠  10♥ J♠  6♥\n"
            + "      2♦  9♣  8♣  K♦  2♣  Q♣  J♦  2♥  Q♦  A♦\n"
            + "    3♦  10♦ 2♣  Q♣  5♠  K♣  Q♠  6♥  6♦  K♠  Q♠\n"
            + "  8♠  A♠  6♠  3♠  10♣ K♥  4♠  7♥  6♠  8♦  7♠  10♠\n"
            + "5♣  8♠  3♠  K♥  9♣  J♣  3♦  K♠  5♥  A♣  3♣  2♥  J♣\n"
            + "Draw: A♥, 5♠, 4♣", view.toString());
  }
}
