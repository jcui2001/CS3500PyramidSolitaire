package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.model.hw04.MultiPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw04.RelaxedPyramidSolitaire;

public class PyramidSolitaireCreator {

  public enum GameType {
   BASIC,
   RELAXED,
   MULTIPYRAMID
  }

  public static PyramidSolitaireModel create(GameType type) {
    //
    if (type.equals(GameType.BASIC)) {
      return new BasicPyramidSolitaire();
    }
    if (type.equals(GameType.RELAXED)) {
     return new RelaxedPyramidSolitaire();
    }
    if (type.equals(GameType.MULTIPYRAMID)) {
     return new MultiPyramidSolitaire();
   }

   return null;
 }
}
